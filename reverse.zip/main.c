#include <stdio.h>

int main() {
    int num, originalNum;
    int firstDigit, secondDigit, thirdDigit, reversedNum;

    printf("Enter a 3-digit number: ");
    if (scanf("%d", &num) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    originalNum = num;

    if (num < 0) {
        num = -num;
    }
    if (num < 100 || num > 999) {
        printf("Error: The entered number is not a 3-digit number.\n");
        return 1;
    }

    
    thirdDigit = num % 10;          
    secondDigit = (num / 10) % 10;  
    firstDigit = num / 100;         

    reversedNum = (thirdDigit * 100) + (secondDigit * 10) + firstDigit;

    if (originalNum < 0) {
        reversedNum = -reversedNum;
    }

    
    printf("The reverse of %d is: %d\n", originalNum, reversedNum);

    return 0;
}
