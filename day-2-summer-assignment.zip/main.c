#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int left = 0;
    int right;
    int is_palindrome = 1; 

    printf("Enter a string: ");
    
   
    if (fgets(str, sizeof(str), stdin) != NULL) {
        str[strcspn(str, "\n")] = '\0';
        
        
        right = strlen(str) - 1;

        while (right > left) {
            if (str[left] != str[right]) {
                is_palindrome = 0; 
                break;
            }
            left++;
            right--;
        }
        if (is_palindrome) {
            printf("\"%s\" is a palindrome.\n", str);
        } else {
            printf("\"%s\" is not a palindrome.\n", str);
        }
    }

    return 0;
}