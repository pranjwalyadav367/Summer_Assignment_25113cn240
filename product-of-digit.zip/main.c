#include <stdio.h>
#include <stdlib.h>

int main() {
    int num, temp, remainder;
    long long product = 1; 

    printf("Enter an integer number: ");
    if (scanf("%d", &num) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    
    temp = num;
    if (num < 0) {
        num = -num; 
    }

    
    if (num == 0) {
        product = 0;
    } else {
        while (num > 0) {
            remainder = num % 10;      
            product *= remainder;      
            num /= 10;                  
        }
    }

    printf("The product of the digits of %d is: %lld\n", temp, product);
    return 0;
}
